import './assets/css-react-tcc/tcc.css'
import { Link } from 'react-router-dom'

function App() {
  return (
    <>
        <div>
            <header>
                <div id="title">
                    <h1>Sistema PDV</h1>
                </div>
                <ul>
                    <Link to="/Home"><li>Home</li></Link>
                    
                    <a href="./Components/PagSobr.jsx"><li>Sobre nós</li></a>
                   
                    <a href="./Components/PagDown.jsx"><li>Download</li></a>    
                </ul>
            </header>
            <main>
                <aside>
                    <h2>Sun PDV</h2>
                    <p>
                        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quibusdam deserunt iure est doloribus vitae ipsa cupiditate necessitatibus placeat inventore. Harum magni ipsa sequi totam eligendi delectus fugit tenetur ipsam hic!
                    </p>
                </aside>  
            </main>
        </div>
    </>  
  )
}

export default App
