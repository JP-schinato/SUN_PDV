import { createRoot } from 'react-dom/client'
import { Route, Routes, BrowserRouter} from 'react-router-dom';
import './assets/css-react-tcc/tcc.css';
import App from './App.jsx';
import PagHom from './Components/PagHom.jsx';


createRoot(document.getElementById('root')).render(
  <BrowserRouter>
    <Routes>
      <Route path="/" element={<App />} />
      <Route path="/Home" element={<PagHom />} />
    </Routes>

   
  </BrowserRouter>

 
  
  
)
