import React from "react";
import DownloadButton from "./DownloadButton.jsx";
import "./styles/DownloadButton.css"; 

const PagDown = () => {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100 p-6">
      <h1 className="text-3xl font-bold mb-4">Baixe o Sun PDV </h1>
      <p className="text-lg text-gray-700 mb-6">
        Clique no botão abaixo para baixar o Nosso Sistema PDV e iniciar a instalação.
      </p>
      <DownloadButton />
    </div>
  );
};

export default PagDown;