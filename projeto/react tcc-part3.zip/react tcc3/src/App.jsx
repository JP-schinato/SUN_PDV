import './assets/css-react-tcc/tcc.css'
import { Link } from 'react-router-dom'

function App() {
  return (
    <>
        <div>
            <header>
                <div id="title">
                    <h1>Sistema PDV</h1>
                </div>
                <ul>
                    <Link to="/Home"><li>Home</li></Link>
                   
                    <Link to="/Sobre-Nos"><li>Sobre Nós</li></Link>
                    
                    
                    <Link to="/Download"><li>Download</li> </Link>
                    
                </ul>
            </header>
            <main>
                <aside>
                    <h2>Sun PDV</h2>
                    <p>
                        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quibusdam deserunt iure est doloribus vitae ipsa cupiditate necessitatibus placeat inventore. Harum magni ipsa sequi totam eligendi delectus fugit tenetur ipsam hic!
                
                    </p>
                </aside> 
            </main>
        </div>
    </>  
  )
}

export default App
